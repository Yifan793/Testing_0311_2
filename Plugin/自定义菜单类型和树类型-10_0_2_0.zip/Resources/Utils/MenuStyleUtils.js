/**
 * Menu插件的样式工具方法
 */
var Forguncy;
(function (Forguncy) {
    var MenuStyleUtils = /** @class */ (function () {
        function MenuStyleUtils() {
        }
        MenuStyleUtils.InsertArrowFillColorRule = function (container, cssSelector, fillColor) {
            container.prepend("<style>".concat(cssSelector, " {fill: ").concat(fillColor, " !important;}</style>"));
        };
        MenuStyleUtils.InsertForeColorRule = function (container, cssSelector, foreColor) {
            container.prepend("<style>".concat(cssSelector, " {color: ").concat(foreColor, " !important;}</style>"));
        };
        MenuStyleUtils.InsertBackColorRule = function (container, cssSelector, backgroundColor) {
            /**
             * 在渐变色背景下 需要设置此属性 否则run起来的border下的背景会不正确
             * Related Bug 26595: Display of Menu's border is not good in Runtime.
             */
            container.prepend("<style>".concat(cssSelector, " {background: ").concat(backgroundColor, " border-box !important}</style>"));
        };
        MenuStyleUtils.GetBase64FromSvgElement = function (element) {
            var div = document.createElement('div');
            div.appendChild(element.cloneNode(true));
            return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(div.innerHTML)));
        };
        return MenuStyleUtils;
    }());
    Forguncy.MenuStyleUtils = MenuStyleUtils;
})(Forguncy || (Forguncy = {}));
